R6 Discord Bot
=========


Please read the master branch's README before continuing.

This is the daddy bot which started all others. It does pretty much everything a bot can do moderation wise and does it all pretty okay.

I'm too lazy to type this right now and if you're reading this and actually interested in this bot, open an issue with your discord name and send me a friend request and I'll accept and talk it over with you.

