from .bot import R6Bot

__all__ = ['R6Bot']
