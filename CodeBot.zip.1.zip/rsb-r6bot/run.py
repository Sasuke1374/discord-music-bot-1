import os

from r6bot import R6Bot
os.environ["PYTHONUNBUFFERED"] = "1"
R6Bot().run()
